
import React from "react";
import './Villa.css'

export default function Design(){
    return(

        <div style={{marginTop:"20px",width:"100%",height:"200px",backgroundColor:"green"}}>hello</div>
    )
}