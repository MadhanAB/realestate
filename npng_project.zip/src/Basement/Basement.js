
import './Basement.css';
import image5 from '../images/hand-with-cap.png';
import image7 from '../images/icon-img1.png'
import image8 from '../images/icon-img2.png';
import image9 from '../images/icon-img3.png';
import image10 from '../images/icon-img4.png';


export default function Basement(){
    return(
  <div className="box5">
    <img src={image5}></img>
   <div className='box6'>
   <h2>CHECK OUT</h2><span><h2>OUR CREDENTIALS</h2></span>
   <br/>
   <br/>
   <p>straight ahead and on the traack now weere gonna make our dreams come true black gold dont it our way </p>
   </div>

   <div className='box7'>
   
   <div className='box7_inner'>
   <img src={image7}></img>
   </div>

   <div className='box7_inner2'>
   <br/>
    <h2>CONTEMPORARY DESIGN</h2>
    <br/>
    <p>Could you be mine. And when the odds are against him and their dangers work to do. You bet your life Speed Racer.</p>
   </div>
   </div>



   <div className='box8'>
  <div className='box8_inner'>
  <img src={image8}></img>
  </div>
  <div className='box8_inner2'>
  <br/>
    <h2>INNOVATIVE APPROACH</h2>
    <br/>
    <p>Could you be mine. And when the odds are against him and their dangers work to do. You bet your life Speed Racer</p>
  </div>
</div>


<div className='box9'>
 <div className='box9_inner'>
 <img src={image9}></img>
 </div>
 <div className='box9_inner2'>

 <br/>
    <h2>URBAN LIVING AT ITS BEST</h2>
    <br/>
    <p>Could you be mine. And when the odds are against him and their dangers work to do. You bet your life Speed Racer</p>
 </div>
</div>


<div className='box10'>
<div className='box10_inner'>
<img src={image10}></img>
</div>
<div className='box10_inner2'>
<br/>
    <h2>THE TEAM WORK</h2>
    <br/>
    <p>Could you be mine. And when the odds are against him and their dangers work to do. You bet your life Speed Racer</p>

</div>
</div>


  </div>

    )
}